#include "widget.h"
#include "SerialConf.h"
#include "uiinit.h"
#include "module.h"
#include <QApplication>
#include <QTextEdit>
#include <QToolButton>

int main(int argc, char *argv[])
{
    QApplication a(argc, argv);
    Widget w;
    w.show();
    return a.exec();
}


/*---------------------------------------------------------
 * 封装！
 * 在uiinit类里面实现控件放置与布局
 * 在module类里面实现功能
 * 将槽函数尽量用lambda表达式减少耦合
 * 加入Json解析
 *
 *
---------------------------------------------------------*/
Widget::Widget(QWidget *parent)
    : QWidget(parent)
{
    //setupUi(this);
    if (this->objectName().isEmpty())
        this->setObjectName(QString::fromUtf8("Widget"));
    this->resize(940, 450);
    this->setWindowTitle(QCoreApplication::translate("Widget", "Widget", nullptr));
    QMetaObject::connectSlotsByName(this);

    //设置无边框
    //this->setWindowFlags(Qt::WindowMinMaxButtonsHint | Qt::FramelessWindowHint);
    //设置软件图标样式
    this->setWindowIcon(QIcon(":/Icon/zhiying.ico"));
    //主窗口初始化
    startWindowInit();
    //添加自定义界面
    win1* serialConf = new win1();
    dataView* dataView = new class dataView();
    frameView* frameView = new class frameView();
    userConfView* userConfView = new  class userConfView();
    m_pStackedWidget->addWidget(serialConf);
    m_pStackedWidget->addWidget(dataView->widget());
    m_pStackedWidget->addWidget(frameView->widget());
    m_pStackedWidget->addWidget(userConfView->widget());

    qssInit(":/qss/test.css");
    m_pStackedWidget->setCurrentIndex(0);
    //串口读取数据通过信号发送给qAgreement类解析出原始帧数据
    connect(serialConf, &win1::DatatoCRC_signal,frameView->pqAgreement,&qAgreement::analysis);
    //原始帧数据通过信号发送给userConfView类按相应配置进行解析
    connect(frameView->pqAgreement, &qAgreement::frameQuoteSignal,userConfView,&userConfView::combinationUserData);
    //解析完成的最终结果发送到进行显示
    connect(userConfView, &userConfView::combinationOk,frameView,&frameView::addText);
    connect(userConfView, &userConfView::userData,dataView,&dataView::refreshUserView);
}

Widget::~Widget(){}

void Widget::startWindowInit(void){
    QVBoxLayout* mainLayout = new QVBoxLayout(this);
    //设置布局边距Policy
    mainLayout->setContentsMargins(0,0,0,0);
    mainLayout->setSpacing(0);

    /*添加自定义界面组件 */
    m_pStackedWidget = new QStackedWidget();
    /*底部主界面栏*/
    // 提升layout控件为frame
    QFrame* lowLayoutFrame = new QFrame(this);
    QHBoxLayout* lowLayout = new QHBoxLayout(lowLayoutFrame);
    //设置布局边距
    lowLayout->setContentsMargins(3,3,3,3);
    //加入QTextEdit软件描述
    QTextEdit* babasay = new QTextEdit(lowLayoutFrame);
    babasay->setReadOnly(true);
    babasay->setText("babasay!");
    lowLayout->addWidget(babasay);
    //配置按钮
    auto buttonInit = [=](QString name , QString iconPath){
        QToolButton* newTButton = new QToolButton(lowLayoutFrame);
        newTButton->setText(name);
        newTButton->setFocusPolicy(Qt::WheelFocus);
        QIcon icon;
        icon.addFile(iconPath, QSize(), QIcon::Normal, QIcon::Off);
        newTButton->setIcon(icon);
        newTButton->setIconSize(QSize(40, 40));
        newTButton->setToolButtonStyle(Qt::ToolButtonTextUnderIcon);
        newTButton->setAutoRaise(true);
        lowLayout->addWidget(newTButton);
        return newTButton;
    };
    //创建按钮并绑定槽函数
    auto addTButton = [=]{
        static QToolButton* serialConf = buttonInit("串口配置",":/Icon/ser.ico");
        connect(serialConf ,&QPushButton::clicked,this,[this]() {
            m_pStackedWidget->setCurrentIndex(0);
        });
        static QToolButton* dataView = buttonInit("数据面板",":/Icon/data.ico");
        connect(dataView ,&QPushButton::clicked,this,[this]() {
            m_pStackedWidget->setCurrentIndex(1);

        });
        static QToolButton* protocolResolution = buttonInit("协议解析",":/Icon/tell.ico");
        connect(protocolResolution ,&QPushButton::clicked,this,[this]() {
            m_pStackedWidget->setCurrentIndex(2);
        });
        static QToolButton* userConf = buttonInit("用户配置",":/Icon/user.ico");
        connect(userConf ,&QPushButton::clicked,this,[this]() {
            m_pStackedWidget->setCurrentIndex(3);

        });
        static QToolButton* waveformDisplay = buttonInit("波形显示",":/Icon/bx.ico");
        connect(waveformDisplay ,&QPushButton::clicked,this,[]() {

        });
        static QToolButton* sendCmd = buttonInit("命令发送",":/Icon/message.ico");
        connect(sendCmd ,&QPushButton::clicked,this,[]() {

        });
        static QToolButton* protocolManual = buttonInit("协议手册",":/Icon/txxy.ico");
        connect(protocolManual ,&QPushButton::clicked,this,[]() {

        });
        static QToolButton* beSmall = buttonInit("隐藏窗口",":/Icon/small.ico");
        connect(beSmall ,&QPushButton::clicked,this,[=]() {
            this->setWindowState(Qt::WindowMinimized);
        });
        static QToolButton* closeSoftware = buttonInit("退出软件",":/Icon/close.ico");
        connect(closeSoftware ,&QPushButton::clicked,this,[=]() {
            this->close();
            //     delete ui;
        });

    };
    addTButton();
    //加入基础上面两个基础控件到主界面布局
    mainLayout->addWidget(m_pStackedWidget);
    mainLayout->addWidget(lowLayoutFrame);
    //设置布局排版
    mainLayout->setStretch(0,9);
    mainLayout->setStretch(1,1);
    this->setLayout(mainLayout);



}

void Widget::qssInit(QString filePath){
    //加载样式表
    if (!filePath.isEmpty()) {
        QFile file(filePath);

        if (file.open(QFile::ReadOnly)) {
            QString qss = file.readAll();
            //            QString qss = QLatin1String(file.readAll());
            this->setStyleSheet(qss);
        }
    }
}
